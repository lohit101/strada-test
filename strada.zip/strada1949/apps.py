from django.apps import AppConfig


class Strada1949Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'strada1949'
